# Installing SQLite from sources

_sudo apt-get install libreadline-dev_

_wget https://www.sqlite.org/2017/sqlite-autoconf-3160200.tar.gz_

# SQLite version 3.16.2. 

# unpack the compressed files.

_tar -xzvf sqlite-autoconf-3160200.tar.gz_

 # Go to the sqlite-autoconf-3160200 directory. 
 _cd sqlite-autoconf-3160200/_
 
 
 # run the configure script.
 
 _./configure_
 
 # we build SQLite.
 
 _make_
 
 # we install SQLite on the system. 
 
 _sudo make install_
 
which sqlite3 
 
 
 
 
 
 
 
 
 
 
 
