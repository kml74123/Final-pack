#!/bin/bash

echo "show running level and the time access"
who -r 
runlevel



